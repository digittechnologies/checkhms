<!DOCTYPE html>
<html lang="en">

<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>:: Chech HMS ::</title>
<link rel="icon" href="favicon.ico" type="image/x-icon">

<!-- Core css file -->
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/fonts/line-icons.css">
<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

<!-- Plugins CSS file -->
<link rel="stylesheet" type="text/css" href="assets/css/slicknav.css">
<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/owl.theme.css">

<!-- Project css with  Responsive-->
<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">

</head>
<body>
<!-- Header Area wrapper Starts -->
<header id="header-wrap">
    <nav class="navbar navbar-expand-lg fixed-top scrolling-navbar indigo">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-navbar"
                    aria-controls="main-navbar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    <span class="icon-menu"></span>
                    <span class="icon-menu"></span>
                    <span class="icon-menu"></span>
                </button>
                <a href="index.html" class="navbar-brand"><img src="assets/img/logo.png" alt=""></a>
            </div>
            <div class="collapse navbar-collapse" id="main-navbar">
                <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
                    <li class="nav-item active"><a class="nav-link" href="#hero-area">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="#feature">Feature</a></li>
                    <li class="nav-item"><a class="nav-link" href="#team">Team</a></li>
                    <li class="nav-item"><a class="nav-link" href="#pricing">Pricing</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                </ul>
                <div class="btn-sing float-right">
                    <a class="btn btn-border" href="../html/page-login.html">Sign In</a>
                </div>
            </div>
        </div>

        <ul class="mobile-menu navbar-nav">
            <li><a class="page-scroll" href="#hero-area">Home</a></li>
            <li><a class="page-scroll" href="#services">Services</a></li>
            <li><a class="page-scroll" href="#feature">feature</a></li>
            <li><a class="page-scroll" href="#team">Team</a></li>
            <li><a class="page-scroll" href="#pricing">Pricing</a></li>
            <li><a class="page-scroll" href="#contact">Contact</a></li>
        </ul>

    </nav>

    <div id="hero-area" class="hero-area-bg particles_js">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="contents text-center">
                        <h2 class="head-title wow fadeInUp">Awesome App for Your Hospital Management System<br>
                            For Clinics, Phamarcy, Radiology and Laboratory</h2>
                        <div class="header-button wow fadeInUp" data-wow-delay="0.3s">
                            <a href="register.php" class="btn btn-common">Get Stated</a>
                            <a href="#" class="btn btn-common blush">View Demo</a>
                        </div>
                    </div>
                    <div class="img-thumb text-center wow fadeInUp" data-wow-delay="0.6s">
                        <img class="img-fluid" src="assets/img/hero-1.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div id="particles-js"></div>
    </div>
    <!-- Hero Area End -->

</header>

<!-- Services Section Start -->
<section id="services" class="section-padding">
    <div class="container">
        <div class="section-header text-center wow fadeInDown" data-wow-delay="0.3s">
            <h2 class="section-title">Our Services</h2>
            <p>Dantes remained confused and silent by this explanation of the thoughts which had unconsciously<br> been working in his mind, or rather soul.</p>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="0.3s">
                    <div class="icon">
                        <i class="lni-cog"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">Web Development</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="0.6s">
                    <div class="icon">
                        <i class="lni-layers"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">Graphic Design</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="0.9s">
                    <div class="icon">
                        <i class="lni-pencil-alt"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">Content Writing</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="1.2s">
                    <div class="icon">
                        <i class="lni-mobile"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">App Development</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="1.5s">
                    <div class="icon">
                        <i class="lni-briefcase"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">Business Branding</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>            
            <div class="col-md-6 col-lg-4 col-xs-12">
                <div class="services-item wow fadeInUp" data-wow-delay="1.8s">
                    <div class="icon">
                        <i class="lni-bar-chart"></i>
                    </div>
                    <div class="services-content">
                        <h3><a href="#">Digital Marketing</a></h3>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur[...]</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Feature Section Start -->
<div id="feature" class="section-padding">
    <div class="container">
        <div class="row mb-5 vertical-content">
            <div class="col-lg-6 col-md-12">
                <div class="wow fadeInLeft mb-3" data-wow-delay="0.3s">
                    <h2 class="title-h3">Create Something Totally & Amazing Professional Features.</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>                
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="features-box wow fadeInLeft" data-wow-delay="0.3s">
                            <div class="features-icon"><i class="lni-layers"></i></div>
                            <div class="features-content">
                                <h4>Bootstrap 4x</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit[...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="features-box wow fadeInLeft" data-wow-delay="0.6s">
                            <div class="features-icon"><i class="lni-briefcase"></i></div>
                            <div class="features-content">
                                <h4>Free Update</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit[...]</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="mt-3 features_img wow fadeInRight" data-wow-delay="0.7s">
                    <img src="assets/img/features-1.png" alt="" class="img-fluid rounded mx-auto d-block">
                </div>
            </div>
        </div>
        <hr>
        <div class="row mt-5 vertical-content">
            <div class="col-lg-6 col-md-12">
                <div class="mt-3 features_img wow fadeInRight" data-wow-delay="0.7s">
                    <img src="assets/img/features-2.png" alt="" class="img-fluid rounded mx-auto d-block">
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="wow fadeInLeft mb-3" data-wow-delay="0.3s">
                    <h2 class="title-h3">Small Business For Professional Features.</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="features-box wow fadeInLeft" data-wow-delay="0.9s">
                            <div class="features-icon"><i class="lni-cog"></i></div>
                            <div class="features-content">
                                <h4>Easy to Customize</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit[...]</p>                                    
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="features-box wow fadeInLeft" data-wow-delay="1.2s">
                            <div class="features-icon"><i class="lni-leaf"></i></div>
                            <div class="features-content">
                                <h4>W3C Validated Code</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit[...]</p>                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Team Section Start -->
<section id="team" class="section-padding text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-header text-center wow fadeInDown" data-wow-delay="0.3s">
                    <h2 class="section-title">Our Team</h2>
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="team-item text-center">
                    <div class="team-img">
                        <img class="img-fluid" src="assets/img/team/team-01.jpg" alt="">
                        <div class="team-overlay">
                            <div class="overlay-social-icon text-center">
                                <ul class="social-icons">
                                    <li><a href="#"><i class="lni-facebook-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-twitter-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-instagram-filled" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="info-text">
                        <h3><a href="#">Louis Pierce</a></h3>
                        <p>CEO, Oculux Inc.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="team-item text-center">
                    <div class="team-img">
                        <img class="img-fluid" src="assets/img/team/team-02.jpg" alt="">
                        <div class="team-overlay">
                            <div class="overlay-social-icon text-center">
                                <ul class="social-icons">
                                    <li><a href="#"><i class="lni-facebook-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-twitter-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-instagram-filled" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="info-text">
                        <h3><a href="#">Nathan Hunter</a></h3>
                        <p>Sales Lead</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="team-item text-center">
                    <div class="team-img">
                        <img class="img-fluid" src="assets/img/team/team-03.jpg" alt="">
                        <div class="team-overlay">
                            <div class="overlay-social-icon text-center">
                                <ul class="social-icons">
                                    <li><a href="#"><i class="lni-facebook-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-twitter-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-instagram-filled" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="info-text">
                        <h3><a href="#">Debra Stewart</a></h3>
                        <p>Product Designer</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="team-item text-center">
                    <div class="team-img">
                        <img class="img-fluid" src="assets/img/team/team-04.jpg" alt="">
                        <div class="team-overlay">
                            <div class="overlay-social-icon text-center">
                                <ul class="social-icons">
                                    <li><a href="#"><i class="lni-facebook-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-twitter-filled" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="lni-instagram-filled" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="info-text">
                        <h3><a href="#">Marshall Nichols</a></h3>
                        <p>Marketing Head</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Clients Section Start -->
<div id="clients" class="section-padding">
    <div class="container">
        <div class="row text-align-">
            <div class="col-lg-3 col-md-3 col-xs-12 wow fadeInUp" data-wow-delay="0.3s">
                <div class="client-item-wrapper">
                    <img class="img-fluid" src="assets/img/clients/img1.png" alt="">
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-12 wow fadeInUp" data-wow-delay="0.6s">
                <div class="client-item-wrapper">
                    <img class="img-fluid" src="assets/img/clients/img2.png" alt="">
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-12 wow fadeInUp" data-wow-delay="0.9s">
                <div class="client-item-wrapper">
                    <img class="img-fluid" src="assets/img/clients/img3.png" alt="">
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-12 wow fadeInUp" data-wow-delay="1.2s">
                <div class="client-item-wrapper">
                    <img class="img-fluid" src="assets/img/clients/img4.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Testimonial Section Start -->
<section id="testimonial" class="testimonial section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="testimonials" class="owl-carousel wow fadeInUp" data-wow-delay="1.2s">
                    <div class="item">
                        <div class="testimonial-item d-flex">
                            <div class="img-thumb">
                                <img src="assets/img/sm/avatar1.jpg" alt="">
                            </div>                            
                            <div class="content">
                                <p class="description">Holisticly empower leveraged ROI whereas effective
                                    web-readiness. Completely enable emerging meta-services with cross-platform web
                                    services. Quickly initiate inexpensive total linkage rather than extensible
                                    scenarios. Holisticly empower leveraged ROI whereas effective web-readiness.
                                </p>
                                <div class="info">
                                    <h2><a href="#">Lisa Garett</a></h2>
                                    <h3><a href="#">CEO & Founder @Oculux</a></h3>
                                </div>
                            </div>                            
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-item d-flex">
                            <div class="img-thumb">
                                <img src="assets/img/sm/avatar2.jpg" alt="">
                            </div>                            
                            <div class="content">
                                <p class="description">Holisticly empower leveraged ROI whereas effective
                                    web-readiness. Completely enable emerging meta-services with cross-platform web
                                    services. Quickly initiate inexpensive total linkage rather than extensible
                                    scenarios. Holisticly empower leveraged ROI whereas effective web-readiness.
                                </p>
                                <div class="info">
                                    <h2><a href="#">Folisise Chosielie</a></h2>
                                    <h3><a href="#">UX Director @PoppinApp</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Pricing section Start -->
<section id="pricing" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-header text-center wow fadeInDown" data-wow-delay="0.3s">
                    <h2 class="section-title">Best Pricing</h2>
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-4 cool-md-4 col-sm-12">
                <div class="card wow fadeInUp" data-wow-delay="0.3s">
                    <ul class="pricing card-body">
                        <li class="plan-img"><img class="img-fluid rounded-circle" src="../assets/images/plan-1.svg"></li>
                        <li class="price">
                            <h3><span>$</span> 99 <small>/ mo</small></h3>
                            <span>Phamarcy</span>
                        </li>
                        <li>1 GB of space</li>
                        <li>Support at $25/hour</li>
                        <li>Limited cloud access</li>                         
                        <li class="plan-btn"><button class="btn btn-common">Choose plan</button></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 cool-md-4 col-sm-12">
                <div class="card wow fadeInUp" data-wow-delay="0.7s">
                    <ul class="pricing card-body">
                        <li class="plan-img"><img class="img-fluid rounded-circle" src="../assets/images/plan-2.svg"></li>
                        <li class="price">
                            <h3><span>$</span> 199 <small>/ mo</small></h3>
                            <span>Clinic</span>
                        </li>
                        <li>5 GB of space</li>
                        <li>Support at $10/hour</li>
                        <li>Full cloud access</li>                         
                        <li class="plan-btn"><button class="btn btn-common blush">Choose plan</button></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 cool-md-4 col-sm-12">
                <div class="card wow fadeInUp" data-wow-delay="1.0s">
                    <ul class="pricing card-body">
                        <li class="plan-img"><img class="img-fluid rounded-circle" src="../assets/images/plan-3.svg"></li>
                        <li class="price">
                            <h3><span>$</span> 299 <small>/ mo</small></h3>
                            <span>HMS</span>
                        </li>
                        <li>15 GB of space</li>
                        <li>Support at $5/hour</li>
                        <li>Full cloud access</li>                         
                        <li class="plan-btn"><button class="btn btn-common">Choose plan</button></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section Start -->
<div id="contact" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-header text-center wow fadeInDown" data-wow-delay="0.3s">
                    <h2 class="section-title">Want To Get Started</h2>
                    <p>Dolor eius, et fugit itaque maxime minima modi numquam odio omnis placeat!</p>
                </div>
            </div>
        </div>
        <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.4s">
            <div class="col-md-6 col-lg-4 col-sm-12">
                <div class="contact-right-area wow fadeIn">
                    <h2>Get In Touch</h2>
                    <div class="contact-right">
                        <div class="single-contact">
                            <div class="contact-icon">
                                <i class="lni-map-marker"></i>
                            </div>
                            <p>9602 Woodsman St. <br> Hartford, CT 06106</p>
                        </div>
                        <div class="single-contact">
                            <div class="contact-icon">
                                <i class="lni-envelope"></i>
                            </div>
                            <p><a href="#">info@gmail.com</a></p>
                            <p><a href="#">circle@gmail.com</a></p>
                        </div>
                        <div class="single-contact">
                            <div class="contact-icon">
                                <i class="lni-phone-handset"></i>
                            </div>
                            <p><a href="#">+42 2354 6574</a></p>
                            <p><a href="#">+99 2354 9876</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-8 col-sm-12">
                <div class="contact-block">
                    <h2>Contact Form</h2>
                    <form id="contactForm">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Name"
                                        required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" placeholder="Email" id="email" class="form-control" name="email"
                                        required data-error="Please enter your email">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" placeholder="Subject" id="msg_subject" class="form-control"
                                        required data-error="Please enter your subject">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea class="form-control" id="message" placeholder="Your Message" rows="4"
                                        data-error="Write your message" required></textarea>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="submit-button">
                                    <button class="btn btn-common blush" id="form-submit" type="submit">Send Message</button>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer Section Start -->
<footer id="footer" class="footer-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.2s">
                <div class="footer-logo mb-3">
                    <img src="assets/img/logo-light.png" alt="">
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam excepturi quasi, ipsam voluptatem.</p>
            </div>
            <div class="col-lg-2 col-md-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.4s">
                <h3 class="footer-titel">Company</h3>
                <ul>
                    <li><a href="#">Press Releases</a></li>
                    <li><a href="#">Mission</a></li>
                    <li><a href="#">Strategy</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.6s">
                <h3 class="footer-titel">About</h3>
                <ul>
                    <li><a href="#">Career</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Clients</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.8s">
                <h3 class="footer-titel">Find us on</h3>
                <div class="social-icon">
                    <a class="facebook" href="#"><i class="lni-facebook-filled"></i></a>
                    <a class="twitter" href="#"><i class="lni-twitter-filled"></i></a>
                    <a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
                    <a class="linkedin" href="#"><i class="lni-linkedin-filled"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>

<section id="copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p>Copyright © 2018 Oculux All Right Reserved</p>
            </div>
        </div>
    </div>
</section>

<!-- Go to Top Link -->
<a href="#" class="back-to-top"><i class="lni-arrow-up"></i></a>

<!-- Preloader -->
<div id="preloader">
    <div class="loader">
        <img src="../assets/images/icon.svg" width="40" height="40" alt="Oculux">
        <p>Please wait...</p>
    </div>
</div>

<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="assets/js/jquery-min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/wow.js"></script>
<script src="assets/js/scrolling-nav.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/jquery.nav.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/jquery.slicknav.js"></script>
<script src="assets/js/particles.min.js"></script>

<script src="assets/js/main.js"></script>
<script src="assets/js/form-validator.min.js"></script>
<script src="assets/js/contact-form-script.min.js"></script>
<script src="assets/js/particlesjs.js"></script>
</body>
</html>